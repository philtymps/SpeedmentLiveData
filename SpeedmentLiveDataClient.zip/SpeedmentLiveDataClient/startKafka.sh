#!/bin/sh

. /opt/Utilities/setenv.sh

echo "starting Kafka Server"
cd ${HOME}/kafka
sudo ./bin/kafka-server-start.sh ./config/server.properties  > ${STERLING_HOME}/logs/kafka.log 2>&1 & 
cd /opt/Utilities
