./speedmentServer.sh start

