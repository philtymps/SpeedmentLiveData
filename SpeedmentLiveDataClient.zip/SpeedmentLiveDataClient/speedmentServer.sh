#!/bin/sh

SERVICE_NAME=SpeedmentLiveDataClient
PATH_TO_JAR=/opt/Utilities/SpeedmentLiveDataClient
FULL_PATH_TO_JAR=SpeedmentLiveDataClient.jar
PID_PATH_NAME=/tmp/SpeedmentLiveDataClient-pid
CLASSPATH=.;
JAVA_HOME=/opt/ibm/java-x86_64-80
case $1 in
    start)
        echo "Starting $SERVICE_NAME ..."
        if [ ! -f $PID_PATH_NAME ]; then
            cd $PATH_TO_JAR
            nohup $JAVA_HOME/bin/java -cp =$CLASSPATH -jar $FULL_PATH_TO_JAR -props:/speedment-livedata-client.properties -save:speedment-stream.txt /tmp  > SpeedmentLiveDataClient.log 2>&1&
            echo $! > $PID_PATH_NAME
            echo "$SERVICE_NAME started ..."
        else
            echo "$SERVICE_NAME is already running ..."
        fi
    ;;
    stop)
        if [ -f $PID_PATH_NAME ]; then
            PID=$(cat $PID_PATH_NAME);
            echo "$SERVICE_NAME stoping ..."
            kill $PID;
            echo "$SERVICE_NAME stopped ..."
            rm $PID_PATH_NAME
        else
            echo "$SERVICE_NAME is not running ..."
        fi
    ;;
    restart)
        if [ -f $PID_PATH_NAME ]; then
            PID=$(cat $PID_PATH_NAME);
            echo "$SERVICE_NAME stopping ...";
            kill $PID;
            echo "$SERVICE_NAME stopped ...";
            echo "$SERVICE_NAME waiting 10 seconds before restarting...";
            sleep 10
            rm $PID_PATH_NAME
            echo "$SERVICE_NAME starting ..."
            cd $PATH_TO_JAR
            nohup $JAVA_HOME/bin/java -cp =$CLASSPATH  -jar $FULL_PATH_TO_JAR -props:/speedment-livedata-client.properties -save:speedment-stream.txt /tmp  > SpeedmentLiveDataClient.log 2>&1&
            echo $! > $PID_PATH_NAME
            echo "$SERVICE_NAME started ..."
        else
            echo "$SERVICE_NAME is not running ..."
        fi
    ;;
esac 
