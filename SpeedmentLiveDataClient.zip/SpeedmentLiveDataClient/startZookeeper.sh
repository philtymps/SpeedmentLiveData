#!/bin/sh

. /opt/Utilities/setenv.sh

echo "starting Zookeeper"
cd ${HOME}/kafka
sudo ./bin/zookeeper-server-start.sh ./config/zookeeper.properties  > ${STERLING_HOME}/logs/zookeeper.log 2>&1 & 
cd /opt/Utilities
